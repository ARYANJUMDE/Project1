'''
Snake Water Gun Game
1 is for snake
-1 is for water
0 is for gun

'''
import random
#Making Dictionary
Dictionary={
    "snake":1,
    "water":-1,
    "gun":0
}
#Taking Inputs
computer=random.choice(list(Dictionary.keys()))

youchoice=input("Enter Your Choice:")

com=Dictionary[computer]
you=Dictionary[youchoice]
if(com==-1 and you==1 ):
    print("You Won Game")
elif(com==-1 and you==0):
    print("You Lost Game")
elif(com==1 and you==-1):
    print("You lost Game")
elif(com==1 and you==0):
    print("You Won Game")
elif(com==0 and you==-1):
    print("You Won Game")
elif(com==0 and you==1):
    print("You Lost Game")
    
else:
    print("Match Is Draw")

print("Computer chose: "+computer)